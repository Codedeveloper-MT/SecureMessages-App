package encryptmessages;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;

public class EncryptMessages extends JFrame {

    private JMenuBar menubar;
    private JMenu file;
    private JMenuItem open;
    private JMenuItem close;
    private JMenuItem save;
    private JMenuItem clear;
    private JMenuItem encryptMessage;

    private JPanel pnlTopic;
    private JLabel lblTopic;
    private JPanel pnlFrame;
    private JPanel pnlTextA;

    private JTextArea taPlainMessage;
    private JTextArea taEncryptedMessage;

    public EncryptMessages() {
        // Initialize Menu Items
        open = new JMenuItem("Open File...");
        encryptMessage = new JMenuItem("Encrypt Message");
        save = new JMenuItem("Save Encrypted Message");
        clear = new JMenuItem("Clear");
        close = new JMenuItem("Close");

        // Add ActionListeners
        open.addActionListener(new OpenFileActionListener());
        close.addActionListener(new CloseActionListener());
        save.addActionListener(new SaveFileActionListener());
        clear.addActionListener(new ClearActionListener());
        encryptMessage.addActionListener(new EncryptMessageActionListener());

        // Setup Menu Bar
        menubar = new JMenuBar();
        file = new JMenu("File");
        file.add(open);
        file.add(encryptMessage);
        file.add(save);
        file.add(clear);
        file.add(close);
        menubar.add(file);

        // Set up frame panel
        pnlFrame = new JPanel(new GridBagLayout());
        GridBagConstraints layout = new GridBagConstraints();

        // Set up topic panel
        pnlTopic = new JPanel();
        lblTopic = new JLabel("Message Encryptor");
        lblTopic.setFont(new Font("Arial", Font.BOLD, 47));
        lblTopic.setForeground(Color.BLUE);
        pnlTopic.add(lblTopic);
        pnlTopic.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));

        layout.gridx = 0;
        layout.gridy = 0;
        layout.gridwidth = 2;
        layout.insets = new Insets(10, 10, 20, 10);
        layout.anchor = GridBagConstraints.CENTER;
        pnlFrame.add(pnlTopic, layout);

        // Set up text areas
        pnlTextA = new JPanel(new GridBagLayout());
        taPlainMessage = new JTextArea(20, 40);
        taPlainMessage.setLineWrap(true);
        taEncryptedMessage = new JTextArea(20, 40);
        taEncryptedMessage.setLineWrap(true);

        // Create scroll panes for the text areas with titled borders
        JScrollPane scrollPanePlain = new JScrollPane(taPlainMessage);
        scrollPanePlain.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPanePlain.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPanePlain.setBorder(BorderFactory.createTitledBorder("Plain Message"));

        JScrollPane scrollPaneEncrypted = new JScrollPane(taEncryptedMessage);
        scrollPaneEncrypted.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPaneEncrypted.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPaneEncrypted.setBorder(BorderFactory.createTitledBorder("Encrypted Message"));

        // Add Plain Message TextArea with scroll pane
        layout.gridx = 0;
        layout.gridy = 1;
        layout.gridwidth = 1;
        layout.weightx = 0.5;
        layout.fill = GridBagConstraints.BOTH;
        pnlTextA.add(scrollPanePlain, layout);

        // Add Encrypted Message TextArea with scroll pane
        layout.gridx = 1;
        layout.gridy = 1;
        layout.weightx = 0.5;
        pnlTextA.add(scrollPaneEncrypted, layout);

        // Add the text area panel to the main frame panel
        layout.gridx = 0;
        layout.gridy = 1;
        layout.gridwidth = 2;
        layout.insets = new Insets(0, 10, 10, 10);
        pnlFrame.add(pnlTextA, layout);

        // Frame settings
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.setSize(1200, 700);
        this.setContentPane(pnlFrame);
        this.setJMenuBar(menubar);
        this.setTitle("Secure Message");
        this.setVisible(true);
        this.pack();
    }

    private class OpenFileActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                try (BufferedReader br = new BufferedReader(new FileReader(selectedFile))) {
                    taPlainMessage.read(br, null);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    private class EncryptMessageActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String plainText = taPlainMessage.getText();
            String encryptedText = WeDoSecureApps.encrypt(plainText); // Use the encryption method
            taEncryptedMessage.setText(encryptedText);
        }
    }

    private class SaveFileActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showSaveDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileToSave))) {
                    taEncryptedMessage.write(bw);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    private class CloseActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    private class ClearActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            taPlainMessage.setText("");
            taEncryptedMessage.setText("");
        }
    }

    public static class WeDoSecureApps {
        public static String encrypt(String plainText) {
            return caesarCipherEncrypt(plainText, 3); // Caesar Cipher with a shift of 3
        }

        private static String caesarCipherEncrypt(String text, int shift) {
            StringBuilder result = new StringBuilder();
            for (char character : text.toCharArray()) {
                if (Character.isLetter(character)) {
                    char base = Character.isLowerCase(character) ? 'a' : 'A';
                    result.append((char) ((character - base + shift) % 26 + base));
                } else {
                    result.append(character);
                }
            }
            return result.toString();
        }
    }
}
